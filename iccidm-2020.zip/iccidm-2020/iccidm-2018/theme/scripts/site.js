//= require "jquery-1.6.2"
//= require "jquery.lightbox"

$(function() {
  $(".lightbox").lightbox();
});